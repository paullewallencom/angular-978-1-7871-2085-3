import {Component} from '@angular/core';

@Component({
  template: 'Default component!'
})
export class DefaultComponent {} 
