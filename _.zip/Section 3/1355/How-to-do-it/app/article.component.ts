import {Component} from '@angular/core';

@Component({
  template: 'Article component!'
})
export class ArticleComponent {}
