import {Component} from '@angular/core';

@Component({
  template: `
    <h2>Default view!</h2>
  `
})
export class DefaultComponent {}

