import {OpaqueToken} from '@angular/core';

export const LOGO_URL = new OpaqueToken('logo.url');
