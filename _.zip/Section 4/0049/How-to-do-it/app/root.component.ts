import {Component} from '@angular/core';

@Component({
  selector: 'root',
  template: `
    <article default-view></article>
    <article editor-view></article>
  `
})
export class RootComponent {}
