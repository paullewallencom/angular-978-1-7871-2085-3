import {OpaqueToken} from '@angular/core';

export const ArticleToken = new OpaqueToken('app.article');
