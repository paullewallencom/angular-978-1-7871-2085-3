import {Component} from '@angular/core';

@Component({
  selector: 'root',
  template: `
    <article></article>
    <article editor-view></article>
    <article></article>
    <article editor-view></article>
  `
})
export class RootComponent {}
