import {Injectable} from '@angular/core';

@Injectable()
export class ArticleService {
  constructor() { 
    console.log('ArticleService constructor!');
  }
}
