import {Component} from '@angular/core';

@Component({
  selector: 'root',
  template: `
    <h1>app component!</h1>
    <article></article>
    <article></article>
  `
})
export class RootComponent {}
